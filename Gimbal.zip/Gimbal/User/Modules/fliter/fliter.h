#ifndef FLITER_H
#define FLITER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "cmsis_os.h"
#include "crc_ref.h"
#include "daemon.h"
#include "motor_def.h"
#include "stdlib.h"
#include "stm32f407xx.h"
#include "string.h"
#include "user_lib.h"

typedef enum
{
    LOW_PASS,
    /*ǰ��������Ժ�����̽����*/
    // HIGH_PASS,
} fliter_type_e;

typedef struct {
    fliter_type_e fliter_type; // �˲�������
} FliterInstance;

// Ϊ�˺���ͳһ�ʱ�����װ
typedef struct {
    float RC; // ����ϵ��
} Low_Pass_Fliter_Init_Config_s;

typedef struct {
    fliter_type_e fliter_type;
    float prev_out;
    float RC;
    uint32_t DWT_CNT;
} LPFliterInstance;

void LowPassFliterInit(LPFliterInstance *instance, Low_Pass_Fliter_Init_Config_s *config);

float FliterCalcutale(FliterInstance *fliter_ptr, float input);

#ifdef __cplusplus
}
#endif

#endif // FLITER_H
