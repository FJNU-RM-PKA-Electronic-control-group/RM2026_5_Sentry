#include "bsp_pwm.h"
#include "buzzer.h"
#include "bsp_dwt.h"
#include "string.h"
#include "stdlib.h"

PWMInstance *buzzer;
// static uint8_t idx;
static BuzzzerInstance *buzzer_list[BUZZER_DEVICE_CNT] = {0};

/**
 * @brief ��������ʼ��
 *
 */
void BuzzerInit()
{
    PWM_Init_Config_s buzzer_config = {
        .htim = &htim4,
        .channel = TIM_CHANNEL_3,
        .dutyratio = 0,
        .period = 0.001,
    };
    buzzer = PWMRegister(&buzzer_config);
}

BuzzzerInstance *BuzzerRegister(Buzzer_config_s *config)
{
	static int cnt = 0;
    if (config->alarm_level > BUZZER_DEVICE_CNT) // �������ʵ����,�������ӻ�鿴�Ƿ����ڴ�й©
        while (1)
            ;
    BuzzzerInstance *buzzer_temp = (BuzzzerInstance *)malloc(sizeof(BuzzzerInstance));
    memset(buzzer_temp, 0, sizeof(BuzzzerInstance));

    buzzer_temp->alarm_level = config->alarm_level;
    buzzer_temp->loudness = config->loudness;
    buzzer_temp->octave = config->octave;
    buzzer_temp->alarm_state = ALARM_OFF;

    buzzer_list[cnt] = buzzer_temp;
	cnt++;
    return buzzer_temp;
}

void AlarmSetStatus(AlarmState_e state)
{
    if(state == ALARM_ON)
		PWMSetDutyRatio(buzzer,1);
	else
		PWMSetDutyRatio(buzzer,0);
}

void AlarmSetOctave(float octave)
{
	PWMSetPeriod(buzzer,octave);
}

void BuzzerTask()
{
    BuzzzerInstance *buzz;
    for (size_t i = 0; i < BUZZER_DEVICE_CNT; ++i)
    {
        buzz = buzzer_list[i];
        if (buzz->alarm_state == ALARM_OFF)
        {
            PWMSetDutyRatio(buzzer, 0);
        }
        else
        {
            PWMSetDutyRatio(buzzer, buzz->loudness);
            PWMSetPeriod(buzzer, buzz->octave);

        }
    }
}
