/**
  ****************************(C) COPYRIGHT 2019 DJI****************************
  * @file       test_task.c/h
  * @brief      buzzer warning task.��������������
  * @note
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Nov-11-2019     RM              1. done
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2019 DJI****************************
  */

#include "cmsis_os.h"
#include "main.h"
#include "test_task.h"


#include "buzzer.h"

/**
 * @brief          test task
 * @param[in]      pvParameters: NULL
 * @retval         none
 */
/**
 * @brief          test����
 * @param[in]      pvParameters: NULL
 * @retval         none
 */
void test_task(void const *argument) {

    while (1) {

        osDelay(10);
    }
}
