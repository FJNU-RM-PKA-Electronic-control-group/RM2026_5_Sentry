#include "robot_def.h"
#include "shoot.h"

#include "bsp_dwt.h"
#include "dji_motor.h"
#include "message_center.h"

#define LOADER_STALL_CURRENT_THRESHOLD   4000.0f
#define LOADER_STALL_SPEED_THRESHOLD_APS 100.0f
#define LOADER_STALL_DETECT_TIME_MS      120.0f
#define LOADER_REVERSE_TIME_MS           220.0f
#define LOADER_FORWARD_REF               -55000.0f
#define LOADER_REVERSE_REF               50000.0f

// #include "general_def.h"

/* 对于双发射机构的机器人,将下面的数据封装成结构体即可,生成两份shoot应用实例 */
DJIMotorInstance *friction_l, *friction_r, *loader; // 拨盘电机
DJIMotorInstance DEBUG_friction_l, DEBUG_friction_br, DEBUG_loader;
// static servo_instance *lid; 需要增加弹舱盖

static Publisher_t *shoot_pub;
static Shoot_Ctrl_Cmd_s shoot_cmd_recv;         // 来自cmd的发射控制信息
static Subscriber_t *shoot_sub;
static Shoot_Upload_Data_s shoot_feedback_data; // 来自cmd的发射控制信息

void ShootInit(void) {
    Motor_Init_Config_s friction_config = {
        .can_init_config =
            {
                .can_handle = &hcan1,
            },
        .controller_param_init_config =
            {
                .speed_PID =
                    {
                        .Kp = 2,   // 20
                        .Ki = 0.5, // 1
                        .Kd = 0.001,
                        .Improve =
                            (PID_Improvement_e)(PID_Integral_Limit | PID_Derivative_On_Measurement),
                        .IntegralLimit = 200,
                        .MaxOut        = 15000,
                    },
                .current_PID =
                    {
                        .Kp = 0.4, // 0.7
                        .Ki = 0.1, // 0.1
                        .Kd = 0.001,
                        .Improve =
                            (PID_Improvement_e)(PID_Integral_Limit | PID_Derivative_On_Measurement),
                        .IntegralLimit = 100,
                        .MaxOut        = 15000,
                    },
            },
        .controller_setting_init_config =
            {
                .angle_feedback_source = MOTOR_FEED,
                .speed_feedback_source = MOTOR_FEED,
                .outer_loop_type       = SPEED_LOOP,
                .close_loop_type       = (Closeloop_Type_e)(SPEED_LOOP | CURRENT_LOOP),
                .motor_reverse_flag    = MOTOR_DIRECTION_REVERSE,
            },
        .motor_type = M3508,
    };
    friction_config.can_init_config.tx_id = 1; // 左摩擦轮

    friction_l = DJIMotorInit(&friction_config);

    friction_config.can_init_config.can_handle = &hcan1;
    friction_config.can_init_config.tx_id      = 4; // 右摩擦轮,改txid和方向就行
    friction_config.controller_setting_init_config.motor_reverse_flag = MOTOR_DIRECTION_NORMAL;

    friction_r = DJIMotorInit(&friction_config);

    // 拨盘电机
    Motor_Init_Config_s loader_config = {
        .can_init_config =
            {
                .can_handle = &hcan1,
                .tx_id      = 3,
            },
        .controller_param_init_config =
            {
                .angle_PID =
                    {
                        // 如果启用位置环来控制发弹,需要较大的I值保证输出力矩的线性度否则出现接近拨出的力矩大幅下降
                        .Kp     = 0, // 30
                        .Ki     = 0.0,
                        .Kd     = 0,
                        .MaxOut = 1000,
                    },
                .speed_PID =
                    {
                        .Kp = 1,   // 10
                        .Ki = 3.5, // 1
                        .Kd = 0.001,
                        .Improve =
                            (PID_Improvement_e)(PID_Integral_Limit | PID_Derivative_On_Measurement),
                        .IntegralLimit = 10000,
                        .MaxOut        = 6000,
                    },
                .current_PID =
                    {
                        .Kp = 1.0,   // 0.7
                        .Ki = 800.0, // 0.1
                        .Kd = 0,
                        .Improve =
                            (PID_Improvement_e)(PID_Integral_Limit | PID_Derivative_On_Measurement),
                        .IntegralLimit = 15000,
                        .MaxOut        = 15000,
                    },
            },
        .controller_setting_init_config =
            {
                .angle_feedback_source = MOTOR_FEED,
                .speed_feedback_source = MOTOR_FEED,
                .outer_loop_type =
                    SPEED_LOOP, // 初始化成SPEED_LOOP,让拨盘停在原地,防止拨盘上电时乱转
                .close_loop_type    = (Closeloop_Type_e)(CURRENT_LOOP | SPEED_LOOP),
                .motor_reverse_flag = MOTOR_DIRECTION_REVERSE, // 注意方向设置为拨盘的拨出的击发方向
            },
        .motor_type = M2006};
    loader = DJIMotorInit(&loader_config);

    shoot_pub = PubRegister("shoot_feed", sizeof(Shoot_Upload_Data_s));
    shoot_sub = SubRegister("shoot_cmd", sizeof(Shoot_Ctrl_Cmd_s));
}

/* 机器人发射机构控制核心任务 */
void ShootTask(void) {
    static loader_mode_e load_state;
    static float stall_start_ms   = -1.0f;
    static float reverse_until_ms = 0.0f;
    // 从cmd获取控制数据
    SubGetMessage(shoot_sub, &shoot_cmd_recv);
    load_state       = shoot_cmd_recv.load_mode;
    DEBUG_friction_l = *friction_l;
    DEBUG_loader     = *loader;

    float now_ms             = DWT_GetTimeline_ms();
    float loader_speed_aps   = loader->measure.speed_aps;
    float loader_current     = (float)loader->measure.real_current;
    float loader_speed_abs   = loader_speed_aps >= 0.0f ? loader_speed_aps : -loader_speed_aps;
    float loader_current_abs = loader_current >= 0.0f ? loader_current : -loader_current;

    switch (shoot_cmd_recv.shoot_mode) {
    case SHOOT_OFF:
        DJIMotorStop(friction_l);
        DJIMotorStop(friction_r);
        DJIMotorStop(loader);
        break;
    case SHOOT_ON:
        DJIMotorEnable(friction_l);
        DJIMotorEnable(friction_r);
        DJIMotorEnable(loader);
        break;
    case SHOOT_STOP:
        // DJIMotorEnable(friction_l);
        // DJIMotorEnable(friction_r);
        // DJIMotorStop(loader);
        load_state = LOAD_STOP;
        break;
    default:
        while (1)
            ;
    }
    if (shoot_cmd_recv.rest_heat + 50 >= 240 /*shoot_cmd_recv.heat_limit*/) { // 枪口热量限制

        load_state = LOAD_STOP;
    }

    // 确定是否开启摩擦轮,后续可能修改为键鼠模式下始终开启摩擦轮(上场时建议一直开启)
    if (shoot_cmd_recv.friction_mode == FRICTION_ON) {
        // 根据收到的弹速设置设定摩擦轮电机参考值,需实测后填入
        switch (shoot_cmd_recv.bullet_speed) {
        case SMALL_AMU_15:
            DJIMotorSetRef(friction_l, 0);
            DJIMotorSetRef(friction_r, 0);

            break;
        case SMALL_AMU_18:
            DJIMotorSetRef(friction_l, 0);
            DJIMotorSetRef(friction_r, 0);

            break;
        case SMALL_AMU_30:
            DJIMotorSetRef(friction_l, 0);
            DJIMotorSetRef(friction_r, 0);

            break;
        default: // 当前为了调试设定的默认值4000,因为还没有加入裁判系统无法读取弹速.
            DJIMotorSetRef(friction_l, 35000);
            DJIMotorSetRef(friction_r, 35000);

            break;
        }
    }
    else // 关闭摩擦轮
    {
        DJIMotorSetRef(friction_l, 0);
        DJIMotorSetRef(friction_r, 0);

        load_state = LOAD_STOP;
    }

    uint8_t loader_forward_working = (load_state == LOAD_BURSTFIRE || load_state == LOAD_1_BULLET);
    uint8_t reverse_active         = now_ms < reverse_until_ms;

    if (!reverse_active && loader_forward_working) {
        if (loader_current_abs > LOADER_STALL_CURRENT_THRESHOLD &&
            loader_speed_abs < LOADER_STALL_SPEED_THRESHOLD_APS) {
            if (stall_start_ms < 0.0f)
                stall_start_ms = now_ms;
            else if ((now_ms - stall_start_ms) >= LOADER_STALL_DETECT_TIME_MS) {
                reverse_until_ms = now_ms + LOADER_REVERSE_TIME_MS;
                reverse_active   = 1;
                stall_start_ms   = -1.0f;
            }
        }
        else {
            stall_start_ms = -1.0f;
        }
    }
    else {
        stall_start_ms = -1.0f;
    }

    switch (load_state) {
    // 停止拨盘
    case LOAD_STOP:
        DJIMotorOuterLoop(loader, SPEED_LOOP); // 切换到速度环
        DJIMotorSetRef(loader, 0);             // 同时设定参考值为0,这样停止的速度最快
        break;
    // 单发模式
    case LOAD_1_BULLET:
        break;
    // 连发模式,对速度闭环
    case LOAD_BURSTFIRE:
        DJIMotorOuterLoop(loader, SPEED_LOOP);
        DJIMotorSetRef(loader, LOADER_FORWARD_REF);
        // x颗/秒换算成速度:
        // 已知一圈的载弹量,由此计算出1s需要转的角度,注意换算角速度(DJIMotor的速度单位是angle
        // per second)
        break;
    // 拨盘反转,对速度闭环,后续增加卡弹检测(通过裁判系统剩余热量反馈和电机电流)
    // 也有可能需要从switch-case中独立出来
    case LOAD_REVERSE:
        DJIMotorOuterLoop(loader, SPEED_LOOP);
        DJIMotorSetRef(loader, LOADER_REVERSE_REF);
        // ...
        break;
    default:
        while (1)
            ; // 未知模式,停止运行,检查指针越界,内存溢出等问题
    }

    if (reverse_active && loader_forward_working) {
        DJIMotorOuterLoop(loader, SPEED_LOOP);
        DJIMotorSetRef(loader, LOADER_REVERSE_REF);
    }

    // 反馈数据,目前暂时没有要设定的反馈数据,后续可能增加应用离线监测以及卡弹反馈
    PubPushMessage(shoot_pub, (void *)&shoot_feedback_data);
}
